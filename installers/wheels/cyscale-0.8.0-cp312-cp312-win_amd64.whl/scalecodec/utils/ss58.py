"""SS58 is a simple address format designed for Substrate based chains.
Encoding/decoding according to specification on
https://github.com/paritytech/substrate/wiki/External-Address-Format-(SS58)

"""

from typing import Optional, Union

from hashlib import blake2b

from scalecodec.base import ScaleBytes, RuntimeConfiguration
from scalecodec.utils._ss58 import (  # noqa: F401
    b58decode_bytes,
    ss58_encode_fast as ss58_encode,
)


def ss58_decode(address: str, valid_ss58_format: Optional[int] = None) -> str:
    """
    Decodes given SS58 encoded address to an account ID
    Parameters
    ----------
    address: e.g. EaG2CRhJWPb7qmdcJvy3LiWdh26Jreu9Dx6R1rXxPmYXoDk
    valid_ss58_format

    Returns
    -------
    Decoded string AccountId
    """

    # Check if address is already decoded
    if address.startswith("0x"):
        return address

    if address == "":
        raise ValueError("Empty address provided")

    checksum_prefix = b"SS58PRE"

    address_decoded = b58decode_bytes(address)

    if address_decoded[0] & 0b0100_0000:
        ss58_format_length = 2
        ss58_format = (
            ((address_decoded[0] & 0b0011_1111) << 2)
            | (address_decoded[1] >> 6)
            | ((address_decoded[1] & 0b0011_1111) << 8)
        )
    else:
        ss58_format_length = 1
        ss58_format = address_decoded[0]

    if ss58_format in [46, 47]:
        raise ValueError(f"{ss58_format} is a reserved SS58 format")

    if valid_ss58_format is not None and ss58_format != valid_ss58_format:
        raise ValueError("Invalid SS58 format")

    # Determine checksum length according to length of address string
    if len(address_decoded) in [3, 4, 6, 10]:
        checksum_length = 1
    elif len(address_decoded) in [
        5,
        7,
        11,
        34 + ss58_format_length,
        35 + ss58_format_length,
    ]:
        checksum_length = 2
    elif len(address_decoded) in [8, 12]:
        checksum_length = 3
    elif len(address_decoded) in [9, 13]:
        checksum_length = 4
    elif len(address_decoded) in [14]:
        checksum_length = 5
    elif len(address_decoded) in [15]:
        checksum_length = 6
    elif len(address_decoded) in [16]:
        checksum_length = 7
    elif len(address_decoded) in [17]:
        checksum_length = 8
    else:
        raise ValueError("Invalid address length")

    checksum = blake2b(checksum_prefix + address_decoded[0:-checksum_length]).digest()

    if checksum[0:checksum_length] != address_decoded[-checksum_length:]:
        raise ValueError("Invalid checksum")

    return address_decoded[
        ss58_format_length : len(address_decoded) - checksum_length
    ].hex()


def ss58_encode_account_index(account_index: int, ss58_format: int = 42) -> str:
    """
    Encodes an AccountIndex to an Substrate address according to provided address_type

    Parameters
    ----------
    account_index
    ss58_format

    Returns
    -------
    str
    """

    if 0 <= account_index <= 2**8 - 1:
        account_idx_encoder = RuntimeConfiguration().create_scale_object("u8")
    elif 2**8 <= account_index <= 2**16 - 1:
        account_idx_encoder = RuntimeConfiguration().create_scale_object("u16")
    elif 2**16 <= account_index <= 2**32 - 1:
        account_idx_encoder = RuntimeConfiguration().create_scale_object("u32")
    elif 2**32 <= account_index <= 2**64 - 1:
        account_idx_encoder = RuntimeConfiguration().create_scale_object("u64")
    else:
        raise ValueError("Value too large for an account index")

    return ss58_encode(account_idx_encoder.encode(account_index).data, ss58_format)


def ss58_decode_account_index(
    address: str, valid_ss58_format: Optional[int] = None
) -> int:
    """
    Decodes given SS58 encoded address to an AccountIndex

    Parameters
    ----------
    address
    valid_ss58_format

    Returns
    -------
    Decoded int AccountIndex
    """

    account_index_bytes = ss58_decode(address, valid_ss58_format)

    if len(account_index_bytes) == 2:
        return (
            RuntimeConfiguration()
            .create_scale_object(
                "u8", data=ScaleBytes("0x{}".format(account_index_bytes))
            )
            .decode()
        )
    if len(account_index_bytes) == 4:
        return (
            RuntimeConfiguration()
            .create_scale_object(
                "u16", data=ScaleBytes("0x{}".format(account_index_bytes))
            )
            .decode()
        )
    if len(account_index_bytes) == 8:
        return (
            RuntimeConfiguration()
            .create_scale_object(
                "u32", data=ScaleBytes("0x{}".format(account_index_bytes))
            )
            .decode()
        )
    if len(account_index_bytes) == 16:
        return (
            RuntimeConfiguration()
            .create_scale_object(
                "u64", data=ScaleBytes("0x{}".format(account_index_bytes))
            )
            .decode()
        )
    else:
        raise ValueError("Invalid account index length")


def is_valid_ss58_address(value: str, valid_ss58_format: Optional[int] = None) -> bool:
    """
    Checks if given value is a valid SS58 formatted address, optionally check if address is valid for specified
    ss58_format

    Parameters
    ----------
    value: value to checked
    valid_ss58_format: if valid_ss58_format is provided the address must be valid for specified ss58_format (network) as well

    Returns
    -------
    bool
    """

    # Return False in case a public key is provided
    if value.startswith("0x"):
        return False

    try:
        ss58_decode(value, valid_ss58_format=valid_ss58_format)
    except ValueError:
        return False

    return True


def get_ss58_format(ss58_address: str) -> int:
    """
    Returns the SS58 format for given SS58 address

    Parameters
    ----------
    ss58_address

    Returns
    -------
    int
    """
    address_decoded = b58decode_bytes(ss58_address)

    if address_decoded[0] & 0b0100_0000:
        ss58_format = (
            ((address_decoded[0] & 0b0011_1111) << 2)
            | (address_decoded[1] >> 6)
            | ((address_decoded[1] & 0b0011_1111) << 8)
        )
    else:
        ss58_format = address_decoded[0]

    if ss58_format in [46, 47]:
        raise ValueError(f"{ss58_format} is a reserved SS58 format")

    return ss58_format
